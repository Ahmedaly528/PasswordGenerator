// Function to generate a random password
function generatePassword(length) {
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
    let password = "";
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      password += charset[randomIndex];
    }
    return password;
  }
  
  // Function to generate an AI-based password (using predefined rules)
  function generateAIPassword(length) {
    const vowels = "aeiou";
    const consonants = "bcdfghjklmnpqrstvwxyz";
    const numbers = "0123456789";
    const symbols = "!@#$%^&*()_+";
    let password = "";
  
    for (let i = 0; i < length; i++) {
      if (i % 4 === 0) {
        // Add a consonant
        password += consonants[Math.floor(Math.random() * consonants.length)];
      } else if (i % 4 === 1) {
        // Add a vowel
        password += vowels[Math.floor(Math.random() * vowels.length)];
      } else if (i % 4 === 2) {
        // Add a number
        password += numbers[Math.floor(Math.random() * numbers.length)];
      } else {
        // Add a symbol
        password += symbols[Math.floor(Math.random() * symbols.length)];
      }
    }
    return password;
  }
  
  // DOM Elements
  const passwordInput = document.getElementById("password");
  const copyButton = document.getElementById("copy-btn");
  const generateButton = document.getElementById("generate-btn");
  const aiGenerateButton = document.getElementById("ai-generate-btn");
  const lengthInput = document.getElementById("length");
  const lengthValue = document.getElementById("length-value");
  
  // Update length value display and generate password in real-time
  lengthInput.addEventListener("input", () => {
    const length = parseInt(lengthInput.value);
    lengthValue.textContent = length;
    passwordInput.value = generatePassword(length); // Generate password in real-time
  });
  
  // Event Listeners
  generateButton.addEventListener("click", () => {
    const length = parseInt(lengthInput.value);
    passwordInput.value = generatePassword(length);
  });
  
  aiGenerateButton.addEventListener("click", () => {
    const length = parseInt(lengthInput.value);
    passwordInput.value = generateAIPassword(length);
  });
  
  copyButton.addEventListener("click", () => {
    passwordInput.select();
    document.execCommand("copy");
    alert("Password copied to clipboard!");
  });
  
  // Generate a password on page load
  window.addEventListener("load", () => {
    const initialLength = parseInt(lengthInput.value);
    passwordInput.value = generatePassword(initialLength);
  });