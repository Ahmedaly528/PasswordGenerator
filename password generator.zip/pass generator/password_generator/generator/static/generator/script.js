// DOM Elements
const passwordInput = document.getElementById("password");
const copyButton = document.getElementById("copy-btn");
const generateButton = document.getElementById("generate-btn");
const aiGenerateButton = document.getElementById("ai-generate-btn");
const lengthInput = document.getElementById("length");
const lengthValue = document.getElementById("length-value");

// Character Sets
const charset = {
    lowercase: "abcdefghijklmnopqrstuvwxyz",
    uppercase: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    numbers: "0123456789",
    symbols: "!@#$%^&*()_+",
};

// Generate Random Password
function generatePassword(length, options) {
    let availableChars = "";
    Object.keys(options).forEach(key => {
        if (options[key]) availableChars += charset[key];
    });

    if (!availableChars) {
        alert("Please select at least one character type!");
        return "";
    }

    return Array.from({ length }, () =>
        availableChars[Math.floor(Math.random() * availableChars.length)]
    ).join("");
}

// AI-Based Password Generation
function generateAIPassword(length) {
    const options = {
        uppercase: document.getElementById("uppercase").checked,
        lowercase: document.getElementById("lowercase").checked,
        numbers: document.getElementById("numbers").checked,
        symbols: document.getElementById("symbols").checked,
    };

    let availableChars = "";
    Object.keys(options).forEach(key => {
        if (options[key]) availableChars += charset[key];
    });

    if (!availableChars) {
        alert("Please select at least one character type!");
        return "";
    }

    const pattern = ["consonants", "vowels", "numbers", "symbols"];
    let password = "";

    for (let i = 0; i < length; i++) {
        let type = pattern[i % 4];
        if (type === "consonants") password += availableChars.replace(/[aeiouAEIOU]/g, '')[Math.floor(Math.random() * 21)];
        else if (type === "vowels") password += "aeiouAEIOU"[Math.floor(Math.random() * 10)];
        else password += availableChars[Math.floor(Math.random() * availableChars.length)];
    }

    return password;
}

// Update Strength Indicator
function updateStrength(password) {
    const level = document.querySelector(".strength-level");
    let score = 0;

    if (password.length >= 12) score += 2;
    else if (password.length >= 8) score += 1;

    if (/[A-Z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    const strength = ["red", "orange", "yellow", "green"];
    const width = Math.min((score / 5) * 100, 100);
    level.style.width = `${width}%`;
    level.style.backgroundColor = strength[Math.floor((score / 5) * strength.length)] || "red";
}

// Copy to Clipboard
function copyToClipboard() {
    passwordInput.select();
    navigator.clipboard.writeText(passwordInput.value).then(() => {
        const copyBtn = document.getElementById("copy-btn");
        copyBtn.innerHTML = '<i class="fas fa-check"></i>';
        setTimeout(() => {
            copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
        }, 2000);
    });
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
    function updatePassword() {
        const options = {
            uppercase: document.getElementById("uppercase").checked,
            lowercase: document.getElementById("lowercase").checked,
            numbers: document.getElementById("numbers").checked,
            symbols: document.getElementById("symbols").checked,
        };
        passwordInput.value = generatePassword(lengthInput.value, options);
        updateStrength(passwordInput.value);
    }

    generateButton.addEventListener("click", updatePassword);
    aiGenerateButton.addEventListener("click", () => {
        passwordInput.value = generateAIPassword(lengthInput.value);
        updateStrength(passwordInput.value);
    });

    copyButton.addEventListener("click", copyToClipboard);
    lengthInput.addEventListener("input", () => {
        lengthValue.textContent = lengthInput.value;
        updatePassword();
    });

    // Dark Mode
    const darkModeToggle = document.getElementById("darkModeToggle");
    const body = document.body;

    if (localStorage.getItem("theme") === "dark") {
        body.classList.add("dark-mode");
        darkModeToggle.checked = true;
    }

    darkModeToggle.addEventListener("change", function () {
        if (this.checked) {
            body.classList.add("dark-mode");
            localStorage.setItem("theme", "dark");
        } else {
            body.classList.remove("dark-mode");
            localStorage.setItem("theme", "light");
        }
    });
});