import openai
from django.conf import settings
from django.shortcuts import render
from django.http import JsonResponse

openai.api_key = settings.OPENAI_API_KEY



def index(request):
    return render(request, 'generator/index.html')
def ai_generate_password(request):
    length = int(request.GET.get('length', 12))
    prompt = f"Generate a secure and memorable password of length {length}."
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50,
        n=1,
        stop=None,
        temperature=0.7,
    )
    password = response.choices[0].text.strip()
    return JsonResponse({'password': password})